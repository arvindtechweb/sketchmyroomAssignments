<?php

$file= "event.json";

$data = array();
try
{
    $deletetitle = $_POST['title'];
    $jsondata = file_get_contents($file);
    $data = json_decode($jsondata, true);
    if($deletetitle)
    {
        foreach ( $data as $key => $value) {
            if ($value['Title'] ===   $deletetitle){
                unset( $data[$key]);
            }
        }

        $data = json_encode( $data, true);
        if(file_put_contents($file, $data)) {
            echo 'Data successfully deleted';
        }
        else
            echo "error";
    }
    else
        echo "Title not exist ";

}
catch (Exception $e) {
    echo 'Caught exception: ',  $e->getMessage(), "\n";
}


?>