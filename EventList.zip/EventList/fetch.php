<?php
$file= "event.json";

	   $jsondata = file_get_contents($file);


	   $data = json_decode($jsondata, true);
      

?>
<!DOCTYPE html>
<html>
<head>
    <title>

    </title>
</head>
<body>
    <div>
        <table border="1">
            <thead>
                <tr>
                    <th>Event Title</th>
                    <th>Description</th>
                    <th>Date</th>
                    <th>Type</th>
                </tr>
            </thead>
            <tbody>

                <?php foreach ( $data as $key => $value):?>
            
                <tr>
                    <td>

                        <?php echo $value['Title']; ?>
                    </td>
                    <td>

                        <?php echo $value['Description']; ?>
                    </td>
                    <td>

                        <?php echo $value['Date']; ?>
                    </td>
                    <td>

                        <?php echo $value['EventType']; ?>
                    </td>


                </tr>





                <?php endforeach; ?>



            </tbody>


        </table>
    </div>
</body>
</html>