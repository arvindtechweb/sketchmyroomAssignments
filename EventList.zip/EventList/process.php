<?php

  $file= "event.json";

   $data = array();

  try
  {
	   
	   $formdata = array(
	      'Title'=> $_POST['title'],
	      'Description'=> $_POST['description'],
	      'Date'=>$_POST['date'],
	      'EventType'=> $_POST['type']
	   );

	   
	   $jsondata = file_get_contents($file);

	 
	   $data = json_decode($jsondata, true);

	  
	   array_push($data,$formdata);

      
	   $jsondata = json_encode($data, JSON_PRETTY_PRINT);

	   
	   if(file_put_contents($file, $jsondata)) {
	        echo 'Data successfully saved';
	    }
	   else
	        echo "error";

   }
   catch (Exception $e) {
            echo 'Caught exception: ',  $e->getMessage(), "\n";
   }

?>